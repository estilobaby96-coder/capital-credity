from fastapi import APIRouter, Request
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse

router = APIRouter()

import os
from pathlib import Path
BASE_DIR = Path(__file__).resolve().parent.parent.parent
templates_dir = os.path.join(BASE_DIR, "templates")
templates = Jinja2Templates(directory=templates_dir)

CACHE_HEADERS = {
    "Cache-Control": "no-cache, no-store, must-revalidate"
}

@router.get("/login", response_class=HTMLResponse)
def login_page(request: Request):
    return templates.TemplateResponse(request, "login.html", headers=CACHE_HEADERS)

@router.get("/", response_class=HTMLResponse)
def dashboard_page(request: Request):
    return templates.TemplateResponse(request, "dashboard.html", headers=CACHE_HEADERS)

@router.get("/clientes", response_class=HTMLResponse)
def clientes_page(request: Request):
    return templates.TemplateResponse(request, "clientes.html", headers=CACHE_HEADERS)

@router.get("/emprestimos", response_class=HTMLResponse)
def emprestimos_page(request: Request):
    return templates.TemplateResponse(request, "emprestimos.html", headers=CACHE_HEADERS)

@router.get("/recebimentos", response_class=HTMLResponse)
def recebimentos_page(request: Request):
    return templates.TemplateResponse(request, "recebimentos.html", headers=CACHE_HEADERS)

@router.get("/relatorios", response_class=HTMLResponse)
def relatorios_page(request: Request):
    return templates.TemplateResponse(request, "relatorios.html", headers=CACHE_HEADERS)
